fx_version 'adamant'
games { 'gta5' };

client_script {
	'client.lua',
}
